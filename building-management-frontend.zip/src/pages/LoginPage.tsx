import Login from '@/features/auth/Login';
import React from 'react';
export default function LoginPage() {
  return <Login />;
}